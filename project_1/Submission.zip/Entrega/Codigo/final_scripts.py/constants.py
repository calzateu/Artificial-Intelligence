global color_map
#color_map = 'rainbow'
#color_map = 'hsv'
#color_map = 'brg'
color_map = 'nipy_spectral'
set_fuzzy_methods = ['centroid', 'bisector', 'mom', 'som', 'lom']